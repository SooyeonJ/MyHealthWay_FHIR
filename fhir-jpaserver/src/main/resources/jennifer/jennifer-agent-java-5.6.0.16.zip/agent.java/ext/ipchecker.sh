#!/bin/sh
java -jar ipchecker.jar $1 $2
